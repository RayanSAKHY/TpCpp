#ifndef batiment__hpp
#define batiment__hpp

#include <iomanip>
#include <iostream>
#include <string>
#include <sstream>

char  const * const nom_zz = "ISIMA";
const double latitude_zz   = 45.75919091728384;
const double longitude_zz  = 3.1103735526660263;


#endif
